int test (int p)
{
    if (p == 1)
        return 3;
    else
        while (1) p = p + 1;
}